<section class="addVehicle">
<article>
<h4>Terms and Conditions</h4><br>
<p>
1. Vehicle added to the page are personal property of the account holder him/her self. In case of any issues related to the property appers, this site is not responsible.<br>
2. Vehicle added to the page are cleared from any sort of taxes or loans.<br>
3. The images of the bike and bill book are the latest ones.<br>
4. Safari Express charges 5% of the total price you entered which will be added to the vehicle at display time.<br>
5. If seller changes his mind at the time of selling, fine is applicable.<br>
</p>



</article>
<section>