<section class="about">
    <span class="about-title">Our Story</span>
    <div class="about-contents">
        <div class="about-desc">
            <p>
                Safari Express started in providing platform for day to day users helping them buy and sell used bikes/scooters. We are still on development and will soon be introducing 4 wheelers in our site as well.
            </p>

            <p>
                We have been operating since 2022, and have provided exceptional service to our customers. 
            </p>
            
        </div>
        <div class="about-motiv">
            <span class="about-pin"><i class="fa-solid fa-motorcycle"></i></span>
            <span class="about-mt">Find <span> Motorvehicles </span> </span>
            <span class="about-md">We help you find your desired vehicle on a resonable price </span>
        </div>
    </div>
</section>