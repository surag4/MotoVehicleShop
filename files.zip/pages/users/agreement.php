<?php
$title="Agreement";
$content = loadTemplate('../templates/users/agreementTemplate.php', []);

?>