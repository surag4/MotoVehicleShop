<?php
    $title="About";
	$content = loadTemplate('../templates/users/aboutTemplate.php', []);//load template
?>